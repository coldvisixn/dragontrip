# Investigation report

Project: **Delivery acceptance**

Generated: 2026-10-17T07:23:50.494768+00:00



## Executive summary

Owned synthetic fixture exercise. Evidence reviewed; no real target was scanned.

## Findings summary

1 findings selected. Status filter: confirmed; minimum severity: info.

| Severity | Count |
| --- | ---: |
| critical | 0 |
| high | 0 |
| medium | 0 |
| low | 0 |
| info | 1 |

## Findings

### Manual fixture review

Severity: **info** · Status: confirmed

Explicit test finding: manual review of an owned fixture.

No real vulnerability claim.

#### Remediation

Not specified.

Evidence: fixture-proof.png · SHA-256 `4e11eeabcc1346ef6f2ed33763c332d6b817d834a02356ed3717bc144a7b2dee`

#### Retest history

- 2026-10-17T07:23:49.392660+00:00 · still_present

Fixture retest: recorded explicit manual verification and retained the screenshot.

## Object inventory

| Type | Object |
| --- | --- |
| application | http://app.htb |
| application | http://admin.htb |
| domain | admin.htb |
| domain | app.htb |
| endpoint | GET http://admin.htb/login |
| endpoint | POST http://app.htb/login?q=1 |
| endpoint | GET http://app.htb/login?q=1 |
| host | 10.10.10.10 |

## Selected evidence files

- [fixture-proof.png](evidence/f5f5f0dc-0aea-485b-9eac-db975ca8c06b.png) · SHA-256 `4e11eeabcc1346ef6f2ed33763c332d6b817d834a02356ed3717bc144a7b2dee`