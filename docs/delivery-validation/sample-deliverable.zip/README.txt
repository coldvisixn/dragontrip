Open report.html in a browser. It is self-contained and printable.
report.md is a Markdown copy. evidence/ contains only explicitly selected files.
No vault entries, raw scan buffers, or editor drafts are included.
